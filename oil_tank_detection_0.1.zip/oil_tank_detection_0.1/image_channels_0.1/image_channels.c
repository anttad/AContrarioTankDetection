/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*----------------------------------------------------------------------------*/
/*
   Fatal error, print a message to standard-error output and exit.
 */
static void error(char * msg)
{
  fprintf(stderr,"Error: %s\n",msg);
  exit(EXIT_FAILURE);
}

/*----------------------------------------------------------------------------*/
/** Memory allocation, print an error and exit if fail.
 */
static void * xmalloc(size_t size)
{
  void * p;
  if( size == 0 ) error("xmalloc: zero size");
  p = malloc(size);
  if( p == NULL ) error("xmalloc: out of memory");
  return p;
}

/*----------------------------------------------------------------------------*/
/** Open file, print an error and exit if fail.
 */
FILE * xfopen(const char * path, const char * mode)
{
  FILE * f = fopen(path,mode);
  if( f == NULL ) error("xfopen: unable to open file");
  return f;
}

/*----------------------------------------------------------------------------*/
/** Close file, print an error and exit if fail.
 */
int xfclose(FILE * f)
{
  if( fclose(f) == EOF ) error("xfclose: unable to close file");
  return 0;
}

/*----------------------------------------------------------------------------*/
double * read_asc(char * name, int * X, int * Y, int * Z, int * C)
{
  FILE * f;
  int i,n;
  double val;
  double * image;

  /* open file */
  f = xfopen(name,"r");

  /* read header */
  n = fscanf(f,"%u%*c%u%*c%u%*c%u",X,Y,Z,C);
  if( n!=4 || *X<=0 || *Y<=0 || *Z<=0 || *C<=0 )
    error("read_asc: invalid asc file A");

  /* get memory */
  image = (double *) xmalloc( *X * *Y * *Z * *C * sizeof(double) );

  /* read data */
  for(i=0; i<(*X * *Y * *Z * *C); i++)
    {
      n = fscanf(f,"%lf%*[^0-9.eE+-]",&val);
      if( n!=1 ) error("read_asc: invalid asc file");
      image[i] = val;
    }

  /* close file */
  xfclose(f);

  return image;
}

/*----------------------------------------------------------------------------*/
void write_asc(double * image, int X, int Y, int Z, int C, char * name)
{
  FILE * f;
  int i;

  /* check input */
  if( image == NULL || X < 1 || Y < 1 || Z < 1 || X < 1 )
    error("write_asc: invalid image");

  f = xfopen(name,"w");                                  /* open file */
  fprintf(f,"%u %u %u %u\n",X,Y,Z,C);                    /* write header */
  for(i=0; i<X*Y*Z*C; i++) fprintf(f,"%.16g ",image[i]); /* write data */
  xfclose(f);                                            /* close file */
}

/*----------------------------------------------------------------------------*/
/*                                    Main                                    */
/*----------------------------------------------------------------------------*/
int main(int argc, char ** argv)
{
  double * image;
  double * channel;
  int X,Y,Z,C;
  int x,y,c;

  /* get input */
  if( argc != 2 ) error("use: image_channels image.asc");
  image = read_asc(argv[1],&X,&Y,&Z,&C);
  if( Z!=1 )   error("only a single channel handled");

  /* get memory */
  channel = (double *) xmalloc( X * Y * sizeof(double) );

  /* extract channels */
  for(c=0; c<C; c++)
    {
      char filename[512];

      for(y=0; y<Y; y++)
        for(x=0; x<X; x++)
          channel[x+y*X] = image[ x + y*X + c*X*Y*Z ];

      sprintf(filename,"%s_channel%d.asc",argv[1],c);      
      write_asc(channel,X,Y,1,1,filename);
    }

  return 0;
}
/*----------------------------------------------------------------------------*/
