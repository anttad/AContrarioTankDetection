Oil tank detection
==================

Version 0.1 - November 16 2018
by rafael grompone von gioi


Requirements
------------

A C compiler, libpng, libtiff, libjpeg, gs, make, unix environment.


Compiling
---------

The compiling instruction is just

  make


Testing
-------

A test on sample images is performed by executing:

  make test

This test should take about a minute. For the result, see next section.


Running
-------

To run the algorithm on a set of image, the images must be stored in a single
directory in TIF format. The images are assumed to have 13 channels and
channels 2, 3, 4 and 8 will be used. The command is the following:

  ./process.sh IN_DIR OUT_DIR

All the files in IN_DIR with extension .tif will be processed. The directory
OUT_DIR is created and all the output is written there. If the execution is
successful, 3 files should be found in OUT_DIR per input image. For example, if
an image with name 'GAN_01553.tif' is in IN_DIR, the algorithm will produce the
following three output files:

  GAN_01553_detection_num.txt
  GAN_01553_detection.pdf
  GAN_01553_detection.txt

The TXT file 'GAN_01553_detection_num.txt' should contain just the number of
detected curves. Because the algorithm process each channel independently, and
each one is processed at with several blur levels, a single tank can produce
several detected curves. These curves would be seen as superposed in the PDF
output.

The PDF file includes a gray-level and normalized version of the input image
with the detections drawn as green curves. The 'GAN_01553_detection.txt' TXT
file includes the coordinates of the detected curves in the ASCII format
described in at 'devernay_1.0_closed_given_radius/README.txt'.
