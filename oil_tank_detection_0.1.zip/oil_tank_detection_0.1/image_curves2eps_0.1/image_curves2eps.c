/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*----------------------------------------------------------------------------*/
/*
   Fatal error, print a message to standard-error output and exit.
 */
static void error(char * msg)
{
  fprintf(stderr,"Error: %s\n",msg);
  exit(EXIT_FAILURE);
}

/*----------------------------------------------------------------------------*/
/** Memory allocation, print an error and exit if fail.
 */
static void * xmalloc(size_t size)
{
  void * p;
  if( size == 0 ) error("xmalloc: zero size");
  p = malloc(size);
  if( p == NULL ) error("xmalloc: out of memory");
  return p;
}

/*----------------------------------------------------------------------------*/
/** Memory re-allocation, print an error and exit if fail.
 */
void * xrealloc(void * p, size_t size)
{
  if( size == 0 ) error("xrealloc: zero size");
  p = realloc(p,size);
  if( p == NULL ) error("xrealloc: out of memory");
  return p;
}

/*----------------------------------------------------------------------------*/
/** Open file, print an error and exit if fail.
 */
static FILE * xfopen(const char * path, const char * mode)
{
  FILE * f = fopen(path,mode);
  if( f == NULL ) error("xfopen: unable to open file");
  return f;
}

/*----------------------------------------------------------------------------*/
/** Close file, print an error and exit if fail.
 */
static int xfclose(FILE * f)
{
  if( fclose(f) == EOF ) error("xfclose: unable to close file");
  return 0;
}

/*----------------------------------------------------------------------------*/
static double * read_asc(char * name, int * X, int * Y, int * Z, int * C)
{
  FILE * f;
  int i,n;
  double val;
  double * image;

  /* open file */
  f = xfopen(name,"r");

  /* read header */
  n = fscanf(f,"%u%*c%u%*c%u%*c%u",X,Y,Z,C);
  if( n!=4 || *X<=0 || *Y<=0 || *Z<=0 || *C<=0 )
    error("read_asc: invalid asc file A");

  /* get memory */
  image = (double *) xmalloc( *X * *Y * *Z * *C * sizeof(double) );

  /* read data */
  for(i=0; i<(*X * *Y * *Z * *C); i++)
    {
      n = fscanf(f,"%lf%*[^0-9.eE+-]",&val);
      if( n!=1 ) error("read_asc: invalid asc file");
      image[i] = val;
    }

  /* close file */
  xfclose(f);

  return image;
}

/*----------------------------------------------------------------------------*/
static double * read_txt(char * filename, int * N)
{
  FILE * f;
  int n,n_alloc;
  double val;
  double * p;

  /* open file */
  f = xfopen(filename,"r");

  /* initialize output */
  n = 0;
  n_alloc = 1;
  p = xmalloc( n_alloc * sizeof(double) );

  /* read points */
  while( fscanf(f,"%lf%*[^0-9.eE+-]",&val) == 1 )
    {
      if( n >= n_alloc )
        {
          n_alloc *= 2;
          p = xrealloc( p, n_alloc * sizeof(double) );
        }
      p[n++] = val;
    }

  /* close file */
  xfclose(f);

  /* return list of points */
  *N = n;
  return p;
}

/*----------------------------------------------------------------------------*/
/*                                    Main                                    */
/*----------------------------------------------------------------------------*/
int main(int argc, char ** argv)
{
  double * image;
  double * curves;
  int X,Y,Z,C;
  int N;
  int i,j,n,c;
  double width = 1.5;
  double radius = 1.0;
  double R = 0.0;
  double G = 1.0;
  double B = 0.0;
  double min,max;

  /* get input */
  if( argc < 3 )
    error("use: image_curves2eps image.asc curves.txt "
          "[width] [radius] [R G B]\n" 
          "     print EPS file to standard output\n"
          "     image can be gray or color and will be quantized to [0,255]");
  image = read_asc(argv[1],&X,&Y,&Z,&C);
  if( Z!=1 || (C!=1 && C!=3) ) error("invalid image: Z!=1 or C!=1 C!=3");
  curves = read_txt(argv[2],&N);
  if( N<=0 || (N%2)!=0 ) error("invalid curves");
  N = N / 2;
  if( argc >= 4 ) width = atof(argv[3]);
  if( argc >= 5 ) radius = atof(argv[4]);
  if( argc >= 8 )
    {
      R = atof(argv[5]);
      G = atof(argv[6]);
      B = atof(argv[7]);
    }

  /* print EPS header */
  printf("%%!PS-Adobe-3.0 EPSF-3.0\n");
  printf("%%%%BoundingBox: 0 0 %d %d\n",X,Y);
  printf("%%%%Creator: image2eps\n");
  printf("%%%%Title: (%s)\n",argv[1]);
  printf("%%%%EndComments\n\n");

  /* find frame's min and max for normalization */
  min = max = image[0];
  for(j=0; j<Y; j++)
    for(i=0; i<X; i++)
      for(c=0; c<C; c++)
        {
          if( image[i + j*X + c*X*Y] > max ) max = image[i + j*X + c*X*Y];
          if( image[i + j*X + c*X*Y] < min ) min = image[i + j*X + c*X*Y];
        }

  /* print image headder */
  printf("gsave\n");
  printf("%d %d scale\n",X,Y);
  printf("%d %d 8 [%d 0 0 %d 0 %d]\n",X,Y,X,-Y,Y);
  if( C==3 )
    {
      /* color image */
      printf("{currentfile 3 %d mul string readhexstring pop} bind\n",X);
      printf("false 3 colorimage\n");
    }
  else
    {
      /* grayscale image */
      printf("{currentfile %d string readhexstring pop} bind\n",X);
      printf("image\n");
    }

  /* print image data */
  n = 0;
  for(j=0; j<Y; j++)
    for(i=0; i<X; i++)
      for(c=0; c<C; c++)
        {
           unsigned char v = 255.0 * (image[i + j*X + c*X*Y] - min) / (max-min);
           printf("%02x",v);
           if( ++n >= 40 )
             {
               n = 0;
               printf("\n");
             }
        }
  if( n > 0 ) printf("\n");
  printf("grestore\n\n");

  /* draw segments */
  printf("%f %f %f setrgbcolor\n",R,G,B);
  for(i=0; i<(N-1); i++)
    if( curves[2*i+0] != -1 && curves[2*i+1] != -1 &&
        curves[2*(i+1)+0] != -1 && curves[2*(i+1)+1] != -1 )
      {
        double x1 =  0.5 + curves[2*i+0];
        double y1 = -0.5 + Y - curves[2*i+1];
        double x2 =  0.5 + curves[2*(i+1)+0];
        double y2 = -0.5 + Y - curves[2*(i+1)+1];

        printf("newpath %f %f %f 0 360 arc closepath fill\n",x1,y1,radius);
        printf("newpath %f %f moveto %f %f lineto %f setlinewidth stroke\n",
                x1, y1, x2, y2, width );
      }

  /* finish EPS file */
  printf("showpage\n");
  printf("%%%%EOF\n");

  /* free memory */
  free( (void *) image);
  free( (void *) curves);

  return 0;
}
/*----------------------------------------------------------------------------*/
