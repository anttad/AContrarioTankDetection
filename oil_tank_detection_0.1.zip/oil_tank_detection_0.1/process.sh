#!/bin/bash

# usage
if [ "$#" -lt 2 ]
then
  echo "usage: process.sh IN_DIR OUT_DIR"
  exit 1
fi

IN=$1
OUT=$2

# create output directory
mkdir ${OUT}

# external Ghostscript path
GS=`which gs`

# process each image
for i in ${IN}/*.tif
do
  echo ------------------------------------
  n=`basename $i .tif`
  echo image: $i

  # convert image to ASC format, including all channels and a graylevel version
  ./image2asc_0.1/image2asc $i ${OUT}/$n.asc
  ./image2asc_gray_0.1/image2asc_gray $i ${OUT}/${n}_gray.asc

  # extract channels
  ./image_channels_0.1/image_channels ${OUT}/$n.asc

  # print image size
  echo -n "image size: "
  head -n 1 ${OUT}/$n.asc

  # process channels 2, 3, 4 and 8 (1, 2, 3 and 7, when count starts at zero)
  rm -f ${OUT}/${n}_detection.txt
  for j in ${OUT}/${n}*_channel1.asc ${OUT}/${n}*_channel2.asc ${OUT}/${n}*_channel3.asc ${OUT}/${n}*_channel7.asc
  do
    echo "  channel: $j"
    for s in 0 0.3 0.5 0.7 1
    do
      echo -n "    blur $s computing time(s): "
      TIMEFORMAT=%R

      # compute curves using Devernay algorithm
      # a modified version is used which gives at the output only
      # closed curves, roughly circular with a given range of radius
      time ./devernay_1.0_closed_given_radius/devernay $j -t ${OUT}/dv.txt -s $s
      cat ${OUT}/dv.txt >> ${OUT}/${n}_detection.txt
    done
  done

  # count number of detected curves
  grep "\-1 \-1" ${OUT}/${n}_detection.txt | wc -l > ${OUT}/${n}_detection_num.txt
  echo total number of curves detected: `cat ${OUT}/${n}_detection_num.txt`
  echo

  # add an end-of-curve code so image_curves2eps can handle empty files
  # (this must be done AFTER counting number of detected curves, otherwise
  #  the count will be increased by one)
  echo "-1 -1" >> ${OUT}/${n}_detection.txt

  # generate vectorial PDF output including image and curves
  ./image_curves2eps_0.1/image_curves2eps ${OUT}/${n}_gray.asc ${OUT}/${n}_detection.txt 1.5 0.75 > ${OUT}/${n}_detection.eps
  $GS -sDEVICE=pdfwrite -dEPSCrop -dPDFSETTINGS=/prepress -o ${OUT}/${n}_detection.pdf ${OUT}/${n}_detection.eps > /dev/null

  # remove auxiliary files
  rm ${OUT}/${n}*asc
  rm ${OUT}/${n}*eps
  rm ${OUT}/dv.txt
done
