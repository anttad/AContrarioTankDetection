/*----------------------------------------------------------------------------

  Copyright (c) 2017 rafael grompone von gioi <grompone@gmail.com>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU Affero General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU Affero General Public License for more details.

  You should have received a copy of the GNU Affero General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  ----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include "iio.h"

/*----------------------------------------------------------------------------*/
/* Fatal error, print a message to standard-error output and exit.            */
void error(char * msg)
{
  fprintf(stderr,"Error: %s\n",msg);
  exit(EXIT_FAILURE);
}

/*----------------------------------------------------------------------------*/
/* memory allocation, print an error and exit if fail
 */
static void * xmalloc(size_t size)
{
  void * p;
  if( size == 0 ) error("xmalloc input: zero size");
  p = malloc(size);
  if( p == NULL ) error("out of memory");
  return p;
}

/*----------------------------------------------------------------------------*/
/* Open file, print an error and exit if fail.                                */
FILE * xfopen(const char * path, const char * mode)
{
  FILE * f = fopen(path,mode);
  if( f == NULL ) error("xfopen: unable to open file");
  return f;
}

/*----------------------------------------------------------------------------*/
/* Close file, print an error and exit if fail.                               */
int xfclose(FILE * f)
{
  if( fclose(f) == EOF ) error("xfclose: unable to close file");
  return 0;
}

/*----------------------------------------------------------------------------*/
/* Write an ASC format image file.                                            */
void write_asc(double * image, int X, int Y, int Z, int C, char * name)
{
  FILE * f;
  int i;

  /* check input */
  if( image == NULL || X < 1 || Y < 1 || Z < 1 || C < 1 )
    error("write_asc: invalid image");

  f = xfopen(name,"w");                                  /* open file    */
  fprintf(f,"%u %u %u %u\n",X,Y,Z,C);                    /* write header */
  for(i=0; i<X*Y*Z*C; i++) fprintf(f,"%.16g ",image[i]); /* write data   */
  xfclose(f);                                            /* close file   */
}

/*----------------------------------------------------------------------------*/
/*                                    Main                                    */
/*----------------------------------------------------------------------------*/
int main(int argc, char ** argv)
{
  double * image;
  double * gray;
  int X,Y,C;
  int x,y,c;

  /* read input */
  if( argc != 3 ) error("use: image2asc <input image> out.asc");

  /* read image using Enric's IIO */
  image = iio_read_image_double_split(argv[1], &X, &Y, &C);

  /* generate single channel image */
  gray = (double *) xmalloc( X * Y * sizeof(double) );
  for(x=0; x<X; x++)
    for(y=0; y<Y; y++)
      {
        gray[x+y*X] = 0.0;
        for(c=0; c<C; c++)
          gray[x+y*X] += image[x+y*X+c*X*Y];
      }

  /* write output */
  write_asc(gray, X, Y, 1, 1, argv[2]);

  /* free memory */
  free( (void *) image );
  free( (void *) gray );

  return EXIT_SUCCESS;
}
/*----------------------------------------------------------------------------*/
